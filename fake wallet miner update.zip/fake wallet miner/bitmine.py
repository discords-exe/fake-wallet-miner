import time
import os
import sys
import colorama
from termcolor import colored
from time import sleep
from os import system, name
from colorama import init, Fore, Back, Style
import platform
import psutil
import random
import string
import ctypes

ctypes.windll.kernel32.SetConsoleTitleW("BITMINE VERSION 1.0 - STATUS: IDLE")

def clear():
  
    # for windows
    if name == 'nt':
        _ = system('cls')
  
    # for mac and linux(here, os.name is 'posix')
    else:
        _ = system('clear')
clear()
time.sleep(0.03)
print("")
time.sleep(0.03)
print(colored("              _     _ _             _               ","magenta"))
time.sleep(0.03)
print(colored("             | |   (_) |           (_)              ","magenta"))
time.sleep(0.03)
print(colored("             | |__  _| |_ _ __ ___  _ _ __   ___    ","magenta"))
time.sleep(0.03)
print(colored("             | '_ \| | __| '_ ` _ \| | '_ \ / _ \   ","magenta"))
time.sleep(0.03)
print(colored("             | |_) | | |_| | | | | | | | | |  __/   ","magenta"))
time.sleep(0.03)
print(colored("             |_.__/|_|\__|_| |_| |_|_|_| |_|\___|   ","magenta"))
time.sleep(0.03)
print("")
time.sleep(0.03)
print("Set Wallet to wallet.txt")
time.sleep(0.5)
print("Setting Proxy to true")
time.sleep(1)
print("Proxy Set to true")
time.sleep(0.5)
print("Location set to Dannmark")
time.sleep(0.3)
print("Loading stuff, please wait.")
time.sleep(3)

ctypes.windll.kernel32.SetConsoleTitleW("bitmine VERSION 1.0 - STATUS: MINING")

def get_random_string(length):
    letters = string.ascii_uppercase + string.digits
    result_str = ''.join(random.choice(letters) for i in range(length))
    print(Fore.WHITE + "[" + Fore.YELLOW + "bitmine" + Fore.WHITE + "]" + "  TRYING WALLET: " + Fore.LIGHTRED_EX + result_str + Fore.WHITE + "  [" + "RESULT: " + Fore.RED + "0.00 BTC" + Fore.WHITE + "]")

for i in range(800):
    get_random_string(35)
    time.sleep(0.02)
    


def get_random_win(length):
    letters = string.ascii_uppercase + string.digits
    result_str = ''.join(random.choice(letters) for i in range(length))
    print(Fore.WHITE + "[" + Fore.GREEN + "bitmine" + Fore.WHITE + "]" + "  FOUND WALLET: " + Fore.LIGHTGREEN_EX + result_str + Fore.WHITE + "  [" + "RESULT: " + Fore.GREEN + "2.72 BTC" + Fore.WHITE + "]")

time.sleep(0.3)

get_random_win(35)

time.sleep(0.5)

ctypes.windll.kernel32.SetConsoleTitleW("BITMINE VERSION 1.0 - STATUS: FOUND BTC!")

print("")
print("")
time.sleep(1)
print(Fore.WHITE + "[" + Fore.CYAN + "BitMine" + Fore.WHITE + "]" + Fore.LIGHTGREEN_EX + " SAVING '2.72 BTC' TO WALLET.TXT" + Fore.WHITE + "  [" + "RESULT: " + Fore.GREEN + "SUCCESS" + Fore.WHITE + "]") 
time.sleep(1)
print("")
print(Fore.CYAN + "BITMINE IS NOW CLOSING...\nHave a nice day!")
time.sleep(1)

closing = Fore.CYAN + "bitmine 2022 ©"
for char in closing:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.07)

time.sleep(1)
print(Fore.RESET)